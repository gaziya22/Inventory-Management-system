from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import os
import random
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression

app = Flask(__name__)
app.secret_key = "your_secret_key"

# =====================================================
# DATABASE FILES
# =====================================================

USER_DB = "users_lightbox.db"
INVENTORY_DB = "database.db"

# =====================================================
# USER DATABASE (LOGIN / SIGNUP)
# =====================================================

def init_user_db():
    if not os.path.exists(USER_DB):
        conn = sqlite3.connect(USER_DB)
        c = conn.cursor()

        c.execute("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fullname TEXT NOT NULL,
            shopname TEXT,
            inventory TEXT,
            username TEXT UNIQUE NOT NULL,
            phone TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
        """)

        conn.commit()
        conn.close()


# =====================================================
# INVENTORY DATABASE
# =====================================================

def init_inventory_db():
    conn = sqlite3.connect(INVENTORY_DB)

    conn.execute("""
    CREATE TABLE IF NOT EXISTS inventory (
        transaction_id TEXT,
        product_id TEXT,
        product_name TEXT,
        brand TEXT,
        category TEXT,
        sub_category TEXT,
        model_number TEXT,
        warranty_months INTEGER,
        supplier_name TEXT,
        supplier_city TEXT,
        procurement_type TEXT,
        purchase_order_id TEXT,
        unit_cost_price REAL,
        unit_selling_price REAL,
        gst_percent REAL,
        discount_percent REAL,
        transaction_type TEXT,
        quantity INTEGER,
        stock_before INTEGER,
        stock_after INTEGER,
        reorder_level INTEGER,
        warehouse_location TEXT,
        rack_number TEXT,
        customer_name TEXT,
        customer_type TEXT,
        sales_channel TEXT,
        transaction_date TEXT,
        payment_status TEXT,
        total_cost_value REAL,
        total_selling_value REAL
    )
    """)

    conn.close()


# =====================================================
# OTP STORE
# =====================================================

otp_store = {}

# =====================================================
# LANDING PAGE
# =====================================================

@app.route("/")
def about():
    return render_template("about.html")


# =====================================================
# LOGIN
# After successful login → direct to inventory home page
# =====================================================

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        conn = sqlite3.connect(USER_DB)
        c = conn.cursor()

        c.execute(
            "SELECT * FROM users WHERE username=? AND password=?",
            (username, password)
        )

        user = c.fetchone()
        conn.close()

        if user:
            session["username"] = username
            flash("Login successful!", "success")

            # DIRECT TO INVENTORY PAGE
            return redirect(url_for("index"))

        else:
            flash("Invalid credentials", "danger")

    return render_template("login_page.html")


# =====================================================
# SIGNUP WITH OTP
# =====================================================

@app.route("/signup", methods=["GET", "POST"])
def signup():
    form_data = {}

    if request.method == "POST":
        action = request.form.get("action")

        fullname = request.form.get("fullname")
        shopname = request.form.get("shopname")
        inventory = request.form.get("inventory")
        username = request.form.get("username")
        phone = request.form.get("phone")
        password = request.form.get("password")
        entered_otp = request.form.get("otp")

        form_data = {
            "fullname": fullname,
            "shopname": shopname,
            "inventory": inventory,
            "username": username,
            "phone": phone
        }

        conn = sqlite3.connect(USER_DB)
        c = conn.cursor()

        # ---------------- GET OTP ----------------

        if action == "get_otp":
            c.execute(
                "SELECT * FROM users WHERE username=?",
                (username,)
            )

            if c.fetchone():
                flash("Username already exists!", "danger")
                conn.close()
                return render_template("signup_page.html", data=form_data)

            c.execute(
                "SELECT * FROM users WHERE phone=?",
                (phone,)
            )

            if c.fetchone():
                flash("Phone already exists!", "danger")
                conn.close()
                return render_template("signup_page.html", data=form_data)

            otp = str(random.randint(1000, 9999))
            otp_store[phone] = otp

            print(f"OTP for {phone}: {otp}")

            flash("OTP sent! Check terminal.", "info")
            conn.close()

            return render_template("signup_page.html", data=form_data)

        # ---------------- VERIFY + FINAL SIGNUP ----------------

        if action == "verify_signup":
            if entered_otp == otp_store.get(phone):
                c.execute("""
                INSERT INTO users
                (
                    fullname,
                    shopname,
                    inventory,
                    username,
                    phone,
                    password
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    fullname,
                    shopname,
                    inventory,
                    username,
                    phone,
                    password
                ))

                conn.commit()
                conn.close()

                flash("Signup successful!", "success")
                return redirect(url_for("login"))

            else:
                conn.close()
                flash("Invalid OTP!", "danger")
                return render_template("signup_page.html", data=form_data)

        conn.close()

    return render_template("signup_page.html", data=form_data)


# =====================================================
# FORGOT PASSWORD
# =====================================================

@app.route("/forgot", methods=["GET", "POST"])
def forgot():
    form_data = {}

    if request.method == "POST":
        action = request.form.get("action")
        phone = request.form.get("phone")
        otp = request.form.get("otp")
        new_password = request.form.get("new_password")

        form_data["phone"] = phone

        # ---------------- GET OTP ----------------

        if action == "get_otp":
            conn = sqlite3.connect(USER_DB)
            c = conn.cursor()

            c.execute(
                "SELECT * FROM users WHERE phone=?",
                (phone,)
            )

            user = c.fetchone()
            conn.close()

            if user:
                generated_otp = str(random.randint(1000, 9999))
                otp_store[phone] = generated_otp

                print(f"OTP for {phone}: {generated_otp}")
                flash("OTP sent!", "info")

            else:
                flash("Phone number not found!", "danger")

            return render_template("forgot_password.html", data=form_data)

        # ---------------- RESET PASSWORD ----------------

        if action == "reset_password":
            if otp == otp_store.get(phone):
                conn = sqlite3.connect(USER_DB)
                c = conn.cursor()

                c.execute(
                    "UPDATE users SET password=? WHERE phone=?",
                    (new_password, phone)
                )

                conn.commit()
                conn.close()

                flash("Password reset successful!", "success")
                return redirect(url_for("login"))

            else:
                flash("Invalid OTP!", "danger")

            return render_template("forgot_password.html", data=form_data)

    return render_template("forgot_password.html", data=form_data)


# =====================================================
# LOGOUT
# =====================================================

@app.route("/logout")
def logout():
    session.pop("username", None)
    flash("Logged out successfully!", "info")
    return redirect(url_for("about"))


# =====================================================
# INVENTORY HOME PAGE
# This opens directly after login
# =====================================================

@app.route("/inventory")
def index():
    if "username" not in session:
        return redirect(url_for("login"))

    return render_template("index.html")


# =====================================================
# UPLOAD CSV / EXCEL
# =====================================================
@app.route("/upload", methods=["GET", "POST"])
def upload():
    if "username" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        file = request.files.get("file")

        if not file or file.filename == "":
            return "⚠️ Please select a file"

        filename = file.filename.lower()

        try:   
            # ---------------- CSV FILE ----------------
            if filename.endswith(".csv"):
                try:
                    df = pd.read_csv(file, encoding="utf-8")
                except:
                    file.seek(0)
                    df = pd.read_csv(file, encoding="latin1")

            # ---------------- EXCEL FILE ----------------
            elif filename.endswith(".xlsx"):
                df = pd.read_excel(file)

            else:
                return "⚠️ Unsupported file format"

        except pd.errors.EmptyDataError:
            return "⚠️ File is empty or invalid"

        except Exception as e:
            return f"⚠️ Error: {str(e)}"

        if df.empty:
            return "⚠️ No data in file"

        # remove extra spaces from column names
        df.columns = df.columns.str.strip()

        # save data in database
        conn = sqlite3.connect(INVENTORY_DB)
        df.to_sql(
            "inventory",
            conn,
            if_exists="append",
            index=False
        )
        conn.close()

        # after upload → go to uploaded data table page
        return redirect(url_for("view_data"))

    return render_template("upload.html")


# =====================================================
# VIEW UPLOADED DATA TABLE
# =====================================================

@app.route("/view_data")
def view_data():
    if "username" not in session:
        return redirect(url_for("login"))

    conn = sqlite3.connect(INVENTORY_DB)

    df = pd.read_sql(
        "SELECT * FROM inventory",
        conn
    )

    conn.close()

    if df.empty:
        return "No uploaded data available"

    table_data = df.to_dict(orient="records")
    columns = df.columns.tolist()

    return render_template(
        "view_data.html",
        table_data=table_data,
        columns=columns
    )

# =====================================================
# APPEND DATA
# =====================================================

@app.route("/append", methods=["GET", "POST"])
def append():
    if "username" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        data = request.form.to_dict()

        df = pd.DataFrame([data])

        conn = sqlite3.connect(INVENTORY_DB)
        df.to_sql("inventory", conn, if_exists="append", index=False)
        conn.close()

        return redirect("/dashboard")

    return render_template("append.html")


# =====================================================
# DASHBOARD
# =====================================================
@app.route("/dashboard")
def dashboard():
    if "username" not in session:
        return redirect(url_for("login"))

    conn = sqlite3.connect(INVENTORY_DB)
    df = pd.read_sql("SELECT * FROM inventory", conn)
    conn.close()

    if df.empty:
        return "No data available"

    # =====================================================
    # KPI CARDS
    # =====================================================

    revenue = df["total_selling_value"].sum()
    cost = df["total_cost_value"].sum()
    profit = revenue - cost
    stock = df["stock_after"].sum()
    transactions = len(df)
    low_stock = len(
        df[df["stock_after"] < df["reorder_level"]]
    )

    # =====================================================
    # BASIC CHARTS
    # =====================================================

    sales_trend = df.groupby(
        "transaction_date"
    )["total_selling_value"].sum().reset_index()

    product_sales = df.groupby(
        "product_name"
    )["total_selling_value"].sum().reset_index()

    customer_type = df.groupby(
        "customer_type"
    )["total_selling_value"].sum().reset_index()

    # =====================================================
    # EXTRA VISUALS
    # =====================================================

    rev_cost = df.groupby(
        "transaction_date"
    )[[
        "total_selling_value",
        "total_cost_value"
    ]].sum().reset_index()

    supplier_perf = df.groupby(
        "supplier_name"
    )["quantity"].sum().reset_index()

    procurement = df.groupby(
        "procurement_type"
    ).size().reset_index(name="count")

    sales_channel = df.groupby(
        "sales_channel"
    ).size().reset_index(name="count")

    # =====================================================
    # PROFIT PER PRODUCT
    # =====================================================

    df["profit_calc"] = (
        df["total_selling_value"]
        - df["total_cost_value"]
    )

    profit_product = df.groupby(
        "product_name"
    )["profit_calc"].sum().reset_index()

    # =====================================================
    # MARGIN CATEGORY
    # =====================================================

    df["margin"] = (
        (
            df["total_selling_value"]
            - df["total_cost_value"]
        )
        / df["total_selling_value"]
    )

    margin_category = df.groupby(
        "category"
    )["margin"].mean().reset_index()

    # =====================================================
    # LOW STOCK TABLE
    # =====================================================

    low_stock_table = df[
        df["stock_after"] < df["reorder_level"]
    ]

    # =====================================================
    # NEW SECTION:
    # PRODUCT NAME + AVAILABLE QUANTITY
    # =====================================================

    product_stock = df.groupby(
        "product_name"
    )["stock_after"].sum().reset_index()

    # =====================================================
    # ML FORECAST
    # =====================================================

    sales_trend = sales_trend.sort_values(
        "transaction_date"
    )

    sales_trend["day"] = range(
        len(sales_trend)
    )

    X = sales_trend[["day"]]
    y = sales_trend["total_selling_value"]

    model = LinearRegression()
    model.fit(X, y)

    future_days = np.array(
        range(
            len(sales_trend),
            len(sales_trend) + 10
        )
    ).reshape(-1, 1)

    forecast = model.predict(
        future_days
    ).tolist()

    # =====================================================
    # RETURN TEMPLATE
    # =====================================================

    return render_template(
        "dashboard.html",

        # KPI
        revenue=revenue,
        cost=cost,
        profit=profit,
        stock=stock,
        transactions=transactions,
        low_stock=low_stock,

        # Charts
        sales_trend=sales_trend.to_dict(
            orient="records"
        ),
        product_sales=product_sales.to_dict(
            orient="records"
        ),
        customer_type=customer_type.to_dict(
            orient="records"
        ),

        # Extra visuals
        rev_cost=rev_cost.to_dict(
            orient="records"
        ),
        supplier_perf=supplier_perf.to_dict(
            orient="records"
        ),
        procurement=procurement.to_dict(
            orient="records"
        ),
        sales_channel=sales_channel.to_dict(
            orient="records"
        ),
        profit_product=profit_product.to_dict(
            orient="records"
        ),
        margin_category=margin_category.to_dict(
            orient="records"
        ),
        low_stock_table=low_stock_table.to_dict(
            orient="records"
        ),

        # NEW SECTION
        product_stock=product_stock.to_dict(
            orient="records"
        ),

        # Existing visuals
        scatter_data=df.to_dict(
            orient="records"
        ),
        heatmap_data=df.to_dict(
            orient="records"
        ),

        # Forecast
        forecast=forecast
    )
# =====================================================
# RUN
# =====================================================

if __name__ == "__main__":
    init_user_db()
    init_inventory_db()
    app.run(debug=True)